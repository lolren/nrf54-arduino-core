/*
 * Arduino Print implementation
 *
 * Licensed under the Apache License 2.0
 */

#include "Print.h"

#include <stdio.h>
#include <string.h>

size_t Print::write(const uint8_t *buffer, size_t size)
{
    size_t written = 0;
    if (buffer == nullptr) {
        return 0;
    }

    for (size_t i = 0; i < size; ++i) {
        written += write(buffer[i]);
    }

    return written;
}

size_t Print::write(const char *str)
{
    if (str == nullptr) {
        return 0;
    }

    return write(reinterpret_cast<const uint8_t *>(str), strlen(str));
}

size_t Print::print(const String &value)
{
    return write(value.c_str());
}

size_t Print::print(const char *value)
{
    return write(value);
}

size_t Print::print(char value)
{
    return write(static_cast<uint8_t>(value));
}

size_t Print::print(unsigned char value, int base)
{
    return print(static_cast<unsigned long>(value), base);
}

size_t Print::print(int value, int base)
{
    return print(static_cast<long>(value), base);
}

size_t Print::print(unsigned int value, int base)
{
    return print(static_cast<unsigned long>(value), base);
}

size_t Print::print(long value, int base)
{
    return printSigned(value, static_cast<uint8_t>(base));
}

size_t Print::print(unsigned long value, int base)
{
    return printNumber(value, static_cast<uint8_t>(base));
}

size_t Print::print(double value, int digits)
{
    return printFloat(value, static_cast<uint8_t>(digits));
}

size_t Print::println(void)
{
    return write('\n');
}

size_t Print::println(const String &value)
{
    size_t count = print(value);
    count += println();
    return count;
}

size_t Print::println(const char *value)
{
    size_t count = print(value);
    count += println();
    return count;
}

size_t Print::println(char value)
{
    size_t count = print(value);
    count += println();
    return count;
}

size_t Print::println(unsigned char value, int base)
{
    size_t count = print(value, base);
    count += println();
    return count;
}

size_t Print::println(int value, int base)
{
    size_t count = print(value, base);
    count += println();
    return count;
}

size_t Print::println(unsigned int value, int base)
{
    size_t count = print(value, base);
    count += println();
    return count;
}

size_t Print::println(long value, int base)
{
    size_t count = print(value, base);
    count += println();
    return count;
}

size_t Print::println(unsigned long value, int base)
{
    size_t count = print(value, base);
    count += println();
    return count;
}

size_t Print::println(double value, int digits)
{
    size_t count = print(value, digits);
    count += println();
    return count;
}

size_t Print::printNumber(unsigned long value, uint8_t base)
{
    if (base < 2) {
        base = 10;
    }

    char buf[33];
    char *ptr = &buf[sizeof(buf) - 1];
    *ptr = '\0';

    do {
        unsigned long digit = value % base;
        *--ptr = (digit < 10) ? static_cast<char>('0' + digit) : static_cast<char>('A' + (digit - 10));
        value /= base;
    } while (value > 0);

    return write(ptr);
}

size_t Print::printSigned(long value, uint8_t base)
{
    if (base == 10 && value < 0) {
        size_t count = write('-');
        count += printNumber(static_cast<unsigned long>(-value), base);
        return count;
    }

    return printNumber(static_cast<unsigned long>(value), base);
}

size_t Print::printFloat(double value, uint8_t digits)
{
    char buf[48];
    int precision = digits > 9 ? 9 : static_cast<int>(digits);
    int written = snprintf(buf, sizeof(buf), "%.*f", precision, value);
    if (written <= 0) {
        return 0;
    }

    return write(buf);
}
